"""Independent SQLite integration test for migration SQL extracted from Store.kt.
Usage: python qa/test_migration.py (no external dependencies).
This is NOT an Android instrumentation/build test.
"""
import re
import sqlite3
from pathlib import Path

src = (Path(__file__).resolve().parents[1]/'app/src/main/java/com/alwarraqa/app/Store.kt').read_text()

def sqls():
    return re.findall(r'db\.execSQL\("([^"]+)"\)', src)

def old_db():
    db=sqlite3.connect(':memory:')
    for ddl in sqls():
        if ddl.startswith('CREATE TABLE ') and 'IF NOT EXISTS' not in ddl:
            db.execute(ddl)
    db.execute('INSERT INTO projects (id,title,description,created) VALUES (1,?,?,?)', ('مخطوط طب','دراسة',123))
    db.execute('INSERT INTO pages (id,project_id,name,path,position) VALUES (1,1,?,?,0)', ('10a','/legacy/img/1.img'))
    db.execute('INSERT INTO notes (id,page_id,x,y,w,h,category,title,observation,interpretation,confidence) VALUES (1,1,?,?,?,?,?,?,?,?,?)',
        (.2,.3,.15,.1,'تملك','تملك أحمد','بالخط المغربي','يثبت التملك','محتمل'))
    return db

def apply_v2(db):
    for table,fields in [
        ('projects', ['library TEXT NOT NULL DEFAULT \'\'','shelfmark TEXT NOT NULL DEFAULT \'\'','author TEXT NOT NULL DEFAULT \'\'','work TEXT NOT NULL DEFAULT \'\'']),
        ('pages', ['folio TEXT NOT NULL DEFAULT \'\'','side TEXT NOT NULL DEFAULT \'\'','sha256 TEXT NOT NULL DEFAULT \'\'','iiif TEXT NOT NULL DEFAULT \'\'']),
        ('notes', ['uuid TEXT NOT NULL DEFAULT \'\'','geometry TEXT NOT NULL DEFAULT \'rect\'','vertices TEXT NOT NULL DEFAULT \'\'','reading TEXT NOT NULL DEFAULT \'\'','references_text TEXT NOT NULL DEFAULT \'\'','researcher TEXT NOT NULL DEFAULT \'\'','search_key TEXT NOT NULL DEFAULT \'\'','updated INTEGER NOT NULL DEFAULT 0'])
    ]:
        for field in fields:
            assert field in src, f'Missing expected SQL addition {field}'
            db.execute(f'ALTER TABLE {table} ADD COLUMN {field}')
    for query in sqls():
        if 'CREATE INDEX IF NOT EXISTS' in query or 'CREATE TABLE IF NOT EXISTS' in query or 'CREATE VIRTUAL TABLE IF NOT EXISTS' in query:
            db.execute(query)
    db.execute("UPDATE notes SET uuid=lower(hex(randomblob(16))) WHERE uuid='' ")
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS notes_uuid_idx ON notes(uuid)")

if __name__=='__main__':
    db=old_db()
    before=db.execute('SELECT id,page_id,x,y,w,h,category,title,observation,interpretation,confidence FROM notes').fetchall()
    apply_v2(db)
    after=db.execute('SELECT id,page_id,x,y,w,h,category,title,observation,interpretation,confidence FROM notes').fetchall()
    assert before==after, 'Legacy record changed'
    assert db.execute('SELECT uuid FROM notes').fetchone()[0]
    assert db.execute('SELECT title,description FROM projects').fetchone()==('مخطوط طب','دراسة')
    assert db.execute('SELECT library,shelfmark,author,work FROM projects').fetchone()==('','','','')
    assert db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='revisions'").fetchone()
    assert db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='relations'").fetchone()
    db.execute("INSERT INTO notes_fts(note_id,normalized) VALUES ('1','تملك احمد بالخط المغربي')")
    assert db.execute("SELECT note_id FROM notes_fts WHERE normalized MATCH 'تملك*'").fetchone()[0]=='1'
    print('PASS — migrated v1 fixture, retained record coordinates and text, added v2 metadata/indexes/relations/history')
