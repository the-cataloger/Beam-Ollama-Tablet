#!/usr/bin/env bash
set -euo pipefail
python3 qa/test_migration.py
if command -v gradle >/dev/null 2>&1; then gradle :app:testDebugUnitTest :app:assembleDebug; else echo 'Android Gradle not found; Android build not run.'; fi
