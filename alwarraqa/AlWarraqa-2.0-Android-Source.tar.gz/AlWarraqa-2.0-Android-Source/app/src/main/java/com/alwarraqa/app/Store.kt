package com.alwarraqa.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
import java.text.Normalizer
import java.util.UUID

/** Compatible with version-1 database (warraqa.db): no destructive migration. */
data class Project(val id: Long, val title: String, val description: String, val library: String = "", val shelfmark: String = "", val author: String = "", val work: String = "")
data class Page(val id: Long, val projectId: Long, val name: String, val path: String, val position: Int, val folio: String = "", val side: String = "", val sha256: String = "", val iiif: String = "")
data class Note(val id: Long, val pageId: Long, val x: Float, val y: Float, val w: Float, val h: Float,
    val category: String, val title: String, val observation: String, val interpretation: String, val confidence: String,
    val uuid: String = "", val geometry: String = "rect", val vertices: String = "", val reading: String = "",
    val references: String = "", val researcher: String = "", val searchKey: String = "", val updated: Long = 0L)
data class Relation(val id: Long, val sourceNoteId: Long, val targetNoteId: Long, val type: String, val rationale: String)

fun searchArabic(input: String): String {
    val normalized = Normalizer.normalize(input, Normalizer.Form.NFKD)
    return normalized.replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
        .replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ٱ','ا').replace('ى','ي').replace('ؤ','و').replace('ئ','ي')
        .lowercase().trim().replace(Regex("\\s+"), " ")
}
class Store(context: Context): SQLiteOpenHelper(context, "warraqa.db", null, 2) {
    override fun onConfigure(db: SQLiteDatabase) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true) }
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', created INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE pages (id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, name TEXT NOT NULL, path TEXT NOT NULL, position INTEGER NOT NULL, FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, page_id INTEGER NOT NULL, x REAL NOT NULL, y REAL NOT NULL, w REAL NOT NULL, h REAL NOT NULL, category TEXT NOT NULL, title TEXT NOT NULL, observation TEXT NOT NULL, interpretation TEXT NOT NULL, confidence TEXT NOT NULL, FOREIGN KEY(page_id) REFERENCES pages(id) ON DELETE CASCADE)")
        migrateV2(db)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if(oldVersion < 2) migrateV2(db)
    }
    private fun migrateV2(db: SQLiteDatabase) {
        listOf("library TEXT NOT NULL DEFAULT ''", "shelfmark TEXT NOT NULL DEFAULT ''", "author TEXT NOT NULL DEFAULT ''", "work TEXT NOT NULL DEFAULT ''").forEach { db.execSQL("ALTER TABLE projects ADD COLUMN $it") }
        listOf("folio TEXT NOT NULL DEFAULT ''", "side TEXT NOT NULL DEFAULT ''", "sha256 TEXT NOT NULL DEFAULT ''", "iiif TEXT NOT NULL DEFAULT ''").forEach { db.execSQL("ALTER TABLE pages ADD COLUMN $it") }
        listOf("uuid TEXT NOT NULL DEFAULT ''", "geometry TEXT NOT NULL DEFAULT 'rect'", "vertices TEXT NOT NULL DEFAULT ''", "reading TEXT NOT NULL DEFAULT ''", "references_text TEXT NOT NULL DEFAULT ''", "researcher TEXT NOT NULL DEFAULT ''", "search_key TEXT NOT NULL DEFAULT ''", "updated INTEGER NOT NULL DEFAULT 0").forEach { db.execSQL("ALTER TABLE notes ADD COLUMN $it") }
        db.execSQL("CREATE INDEX IF NOT EXISTS pages_project_idx ON pages(project_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS notes_page_idx ON notes(page_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS notes_search_idx ON notes(search_key)")
        db.execSQL("CREATE TABLE IF NOT EXISTS relations (id INTEGER PRIMARY KEY AUTOINCREMENT, source_note_id INTEGER NOT NULL, target_note_id INTEGER NOT NULL, type TEXT NOT NULL, rationale TEXT NOT NULL DEFAULT '', FOREIGN KEY(source_note_id) REFERENCES notes(id) ON DELETE CASCADE, FOREIGN KEY(target_note_id) REFERENCES notes(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS revisions (id INTEGER PRIMARY KEY AUTOINCREMENT, note_id INTEGER NOT NULL, recorded INTEGER NOT NULL, previous_json TEXT NOT NULL, FOREIGN KEY(note_id) REFERENCES notes(id) ON DELETE CASCADE)")
        db.execSQL("UPDATE notes SET uuid=lower(hex(randomblob(16))) WHERE uuid='' ")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS notes_uuid_idx ON notes(uuid)")
        db.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts USING fts4(note_id, normalized, tokenize=unicode61)")
        val oldNotes=db.rawQuery("SELECT id,title,observation,interpretation,category FROM notes",null).use { cursor->
            buildList { while(cursor.moveToNext()) add(cursor.getLong(0) to searchArabic((1..4).joinToString(" "){cursor.getString(it)?:""})) }
        }
        oldNotes.forEach { (id,key)->
            db.execSQL("INSERT INTO notes_fts(note_id,normalized) VALUES (?,?)",arrayOf(id.toString(),key))
            db.execSQL("UPDATE notes SET search_key=? WHERE id=?",arrayOf(key,id))
        }
    }
    fun projects(): List<Project> = readableDatabase.rawQuery("SELECT id,title,description,library,shelfmark,author,work FROM projects ORDER BY created DESC,id DESC",null).use { c ->
        buildList { while(c.moveToNext()) add(Project(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6))) }
    }
    fun createProject(title: String): Long = writableDatabase.insertOrThrow("projects",null,ContentValues().apply { put("title", title.trim()); put("description", ""); put("created", System.currentTimeMillis()) })
    fun updateProject(p: Project) { writableDatabase.update("projects",ContentValues().apply { put("title",p.title);put("description",p.description);put("library",p.library);put("shelfmark",p.shelfmark);put("author",p.author);put("work",p.work) },"id=?",arrayOf("${p.id}")) }
    fun pages(projectId: Long): List<Page> = readableDatabase.rawQuery("SELECT id,project_id,name,path,position,folio,side,sha256,iiif FROM pages WHERE project_id=? ORDER BY position,id",arrayOf("$projectId")).use { c ->
        buildList { while(c.moveToNext()) add(Page(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getInt(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8))) }
    }
    fun addPage(projectId: Long, name: String, path: String, sha256: String = "", iiif: String = ""): Long = writableDatabase.insertOrThrow("pages",null,ContentValues().apply {
        put("project_id",projectId);put("name",name);put("path",path);put("sha256",sha256);put("iiif",iiif)
        put("position",pages(projectId).size)
    })
    fun updatePage(p:Page) { writableDatabase.update("pages",ContentValues().apply { put("name",p.name);put("folio",p.folio);put("side",p.side) },"id=?",arrayOf("${p.id}")) }
    fun notes(pageId:Long): List<Note> = readableDatabase.rawQuery("SELECT id,page_id,x,y,w,h,category,title,observation,interpretation,confidence,uuid,geometry,vertices,reading,references_text,researcher,search_key,updated FROM notes WHERE page_id=? ORDER BY id",arrayOf("$pageId")).use { c -> notesFrom(c) }
    fun notesForProject(projectId:Long): List<Note> = readableDatabase.rawQuery("SELECT n.id,n.page_id,n.x,n.y,n.w,n.h,n.category,n.title,n.observation,n.interpretation,n.confidence,n.uuid,n.geometry,n.vertices,n.reading,n.references_text,n.researcher,n.search_key,n.updated FROM notes n JOIN pages p ON p.id=n.page_id WHERE p.project_id=? ORDER BY p.position,n.id",arrayOf("$projectId")).use { c -> notesFrom(c) }
    private fun notesFrom(c:android.database.Cursor):List<Note> = buildList { while(c.moveToNext()) add(Note(c.getLong(0),c.getLong(1),c.getFloat(2),c.getFloat(3),c.getFloat(4),c.getFloat(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9),c.getString(10),c.getString(11),c.getString(12),c.getString(13),c.getString(14),c.getString(15),c.getString(16),c.getString(17),c.getLong(18))) }
    private fun values(n: Note) = ContentValues().apply {
        put("page_id",n.pageId);put("x",n.x);put("y",n.y);put("w",n.w);put("h",n.h);put("category",n.category);put("title",n.title)
        put("observation",n.observation);put("interpretation",n.interpretation);put("confidence",n.confidence)
        put("uuid",n.uuid.ifBlank { UUID.randomUUID().toString() });put("geometry",n.geometry);put("vertices",n.vertices)
        put("reading",n.reading);put("references_text",n.references);put("researcher",n.researcher)
        put("search_key",searchArabic("${n.title} ${n.observation} ${n.interpretation} ${n.reading} ${n.category}"));put("updated",System.currentTimeMillis())
    }
    fun saveNote(n:Note): Long {
        val db=writableDatabase; db.beginTransaction()
        return try {
            val id=if(n.id==0L) db.insertOrThrow("notes",null,values(n)) else {
                val prev=note(n.id)
                if(prev!=null) db.insert("revisions",null,ContentValues().apply { put("note_id",n.id);put("recorded",System.currentTimeMillis());put("previous_json",noteJson(prev).toString()) })
                db.update("notes",values(n),"id=?",arrayOf("${n.id}")); n.id
            }
            db.delete("notes_fts","note_id=?",arrayOf("$id"))
            db.insert("notes_fts",null,ContentValues().apply {
                put("note_id",id.toString());put("normalized",searchArabic("${n.title} ${n.observation} ${n.interpretation} ${n.reading} ${n.category}"))
            })
            db.setTransactionSuccessful();id
        } finally { db.endTransaction() }
    }
    fun note(id:Long):Note?= readableDatabase.rawQuery("SELECT id,page_id,x,y,w,h,category,title,observation,interpretation,confidence,uuid,geometry,vertices,reading,references_text,researcher,search_key,updated FROM notes WHERE id=?",arrayOf("$id")).use { c->notesFrom(c).firstOrNull() }
    fun deleteNote(id:Long) { val db=writableDatabase;db.beginTransaction();try {
        db.delete("notes_fts","note_id=?",arrayOf("$id"));db.delete("notes","id=?",arrayOf("$id"));db.setTransactionSuccessful()
    } finally{db.endTransaction()} }
    fun relations(noteId:Long):List<Relation> = readableDatabase.rawQuery("SELECT id,source_note_id,target_note_id,type,rationale FROM relations WHERE source_note_id=? OR target_note_id=?",arrayOf("$noteId","$noteId")).use { c->buildList { while(c.moveToNext()) add(Relation(c.getLong(0),c.getLong(1),c.getLong(2),c.getString(3),c.getString(4))) } }
    fun link(source:Long,target:Long,type:String,rationale:String) { require(source!=target); writableDatabase.insertOrThrow("relations",null,ContentValues().apply { put("source_note_id",source);put("target_note_id",target);put("type",type);put("rationale",rationale) }) }
    fun search(projectId:Long,query:String):List<Note> {
        val words=Regex("[\\p{L}\\p{N}]+").findAll(searchArabic(query)).map { it.value }.take(8).toList()
        if(words.isEmpty())return emptyList()
        val match=words.joinToString(" AND "){"$it*"}
        val sql="SELECT n.id,n.page_id,n.x,n.y,n.w,n.h,n.category,n.title,n.observation,n.interpretation,n.confidence,n.uuid,n.geometry,n.vertices,n.reading,n.references_text,n.researcher,n.search_key,n.updated FROM notes n JOIN pages p ON p.id=n.page_id JOIN notes_fts f ON f.note_id=CAST(n.id AS TEXT) WHERE p.project_id=? AND f.normalized MATCH ? ORDER BY p.position,n.id LIMIT 1000"
        return try{readableDatabase.rawQuery(sql,arrayOf("$projectId",match)).use{notesFrom(it)}}catch(_:Exception){
            notesForProject(projectId).filter{searchArabic("${it.title} ${it.observation} ${it.reading} ${it.interpretation}").contains(searchArabic(query))}.take(1000)
        }
    }
    fun oldVersions(id:Long):List<JSONObject> = readableDatabase.rawQuery("SELECT previous_json FROM revisions WHERE note_id=? ORDER BY recorded DESC",arrayOf("$id")).use { c->buildList{while(c.moveToNext()) add(JSONObject(c.getString(0)))} }
    fun checkpoint(){ writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).close() }
}
fun noteJson(n:Note):JSONObject=JSONObject().apply {
    put("id",n.id);put("uuid",n.uuid);put("page_id",n.pageId);put("x",n.x);put("y",n.y);put("w",n.w);put("h",n.h)
    put("geometry",n.geometry);put("vertices",n.vertices);put("category",n.category);put("title",n.title);put("observation",n.observation)
    put("reading",n.reading);put("interpretation",n.interpretation);put("confidence",n.confidence);put("references",n.references)
    put("researcher",n.researcher);put("updated",n.updated)
}
