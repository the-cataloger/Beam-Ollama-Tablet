package com.alwarraqa.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import org.json.JSONArray
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Coordinates are always normalized relative to original raster dimensions (0..1). */
enum class Tool { PAN, RECT, POLYGON, POINT, MOVE }
data class Mark(val x:Float,val y:Float,val w:Float,val h:Float,val geometry:String,val vertices:String = "")
class ManuscriptView(context:Context):View(context) {
    var tool:Tool=Tool.PAN
    var notes:List<Note> = emptyList(); set(v){field=v;invalidate()}
    var onMark:((Mark)->Unit)?=null
    var onNoteClick:((Note)->Unit)?=null
    var onNoteMove:((Note)->Unit)?=null
    private var decoder:BitmapRegionDecoder?=null
    private var cachedTile:Bitmap?=null;private var cachedRect:Rect?=null;private var cachedSample=0;private var cachedRequestSample=0
    private var imageWidth=1;private var imageHeight=1
    private var zoom=1f;private var panX=0f;private var panY=0f
    private var startX=0f;private var startY=0f;private var fingerX=0f;private var fingerY=0f
    private var isDrawing=false; private var moved=false
    private val polygon=mutableListOf<Pair<Float,Float>>()
    private var selected:Note?=null
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth=3f;style=Paint.Style.STROKE }
    private val scaleDetector=ScaleGestureDetector(context,object:ScaleGestureDetector.SimpleOnScaleGestureListener(){
        override fun onScale(detector:ScaleGestureDetector):Boolean {
            val oldZoom=zoom
            zoom=(zoom*detector.scaleFactor).coerceIn(1f,16f)
            val factor=zoom/oldZoom
            panX=(panX-detector.focusX+width/2f)*factor+detector.focusX-width/2f
            panY=(panY-detector.focusY+height/2f)*factor+detector.focusY-height/2f
            invalidate();return true
        }
    })
    fun load(file:File) {
        try {
            decoder?.recycle(); decoder=null;cachedTile?.recycle();cachedTile=null;cachedRect=null;cachedSample=0;cachedRequestSample=0
            @Suppress("DEPRECATION") val d=BitmapRegionDecoder.newInstance(file.absolutePath,false)
            decoder=d;imageWidth=d.width;imageHeight=d.height
        } catch (_:Exception) { imageWidth=1;imageHeight=1 }
        zoom=1f;panX=0f;panY=0f;polygon.clear();invalidate()
    }
    fun finishPolygon() {
        if(polygon.size>=3){
            val xs=polygon.map{it.first};val ys=polygon.map{it.second}
            val x=xs.minOrNull()?:0f;val y=ys.minOrNull()?:0f
            val vertices=JSONArray().apply { polygon.forEach { put(JSONArray().put(it.first.toDouble()).put(it.second.toDouble())) } }.toString()
            onMark?.invoke(Mark(x,y,(xs.maxOrNull()?:x)-x,(ys.maxOrNull()?:y)-y,"polygon",vertices))
        }
        polygon.clear();invalidate()
    }
    private fun fit():Float=min(width.toFloat()/imageWidth,height.toFloat()/imageHeight).coerceAtLeast(.00001f)
    private fun originX():Float=(width-imageWidth*fit()*zoom)/2f+panX
    private fun originY():Float=(height-imageHeight*fit()*zoom)/2f+panY
    private fun xToImage(x:Float):Float=((x-originX())/(imageWidth*fit()*zoom)).coerceIn(0f,1f)
    private fun yToImage(y:Float):Float=((y-originY())/(imageHeight*fit()*zoom)).coerceIn(0f,1f)
    private fun xToScreen(x:Float)=originX()+x*imageWidth*fit()*zoom
    private fun yToScreen(y:Float)=originY()+y*imageHeight*fit()*zoom
    override fun onDraw(canvas:Canvas) {
        canvas.drawColor(Color.rgb(26,31,40))
        val d=decoder ?:return
        val left=xToImage(0f);val top=yToImage(0f);val right=xToImage(width.toFloat());val bottom=yToImage(height.toFloat())
        val r=Rect((left*imageWidth).toInt().coerceIn(0,imageWidth-1),(top*imageHeight).toInt().coerceIn(0,imageHeight-1),
            (right*imageWidth).toInt().coerceIn(1,imageWidth),(bottom*imageHeight).toInt().coerceIn(1,imageHeight))
        if(r.width()>0&&r.height()>0) {
            val opts=BitmapFactory.Options();var sample=1
            while(max(r.width()/sample,r.height()/sample)>2100)sample*=2
            try {
                val current=cachedRect
                if(current==null || !current.contains(r) || cachedRequestSample!=sample) {
                    val pad=Rect((r.left-r.width()/4).coerceAtLeast(0),(r.top-r.height()/4).coerceAtLeast(0),
                        (r.right+r.width()/4).coerceAtMost(imageWidth),(r.bottom+r.height()/4).coerceAtMost(imageHeight))
                    var neededSample=sample
                    while(max(pad.width()/neededSample,pad.height()/neededSample)>2600)neededSample*=2
                    opts.inSampleSize=neededSample
                    cachedTile?.recycle();cachedTile=d.decodeRegion(pad,opts);cachedRect=pad;cachedSample=neededSample;cachedRequestSample=sample
                }
                val rect=cachedRect;val bmp=cachedTile
                if(rect!=null&&bmp!=null) canvas.drawBitmap(bmp,null,RectF(originX()+rect.left*fit()*zoom,originY()+rect.top*fit()*zoom,
                    originX()+rect.right*fit()*zoom,originY()+rect.bottom*fit()*zoom),null)
            } catch (_:Throwable) { /* oversized or corrupt image; no crash */ }
        }
        notes.forEach { n ->
            paint.color=if(n.id==selected?.id)Color.YELLOW else Color.rgb(16,180,160)
            paint.style=Paint.Style.STROKE;paint.strokeWidth=3f
            drawGeometry(canvas,n.x,n.y,n.w,n.h,n.geometry,n.vertices)
            paint.style=Paint.Style.FILL;paint.textSize=25f
            canvas.drawText(n.title.take(24),xToScreen(n.x)+4,yToScreen(n.y)-5,paint)
        }
        paint.color=Color.YELLOW;paint.style=Paint.Style.STROKE;paint.strokeWidth=3f
        if(isDrawing&&tool==Tool.RECT){
            canvas.drawRect(min(startX,fingerX),min(startY,fingerY),max(startX,fingerX),max(startY,fingerY),paint)
        }
        if(polygon.isNotEmpty()){
            val path=Path();polygon.forEachIndexed { i,p-> if(i==0)path.moveTo(xToScreen(p.first),yToScreen(p.second)) else path.lineTo(xToScreen(p.first),yToScreen(p.second)) }
            canvas.drawPath(path,paint)
            polygon.forEach { canvas.drawCircle(xToScreen(it.first),yToScreen(it.second),6f,paint) }
        }
    }
    private fun drawGeometry(canvas:Canvas,x:Float,y:Float,w:Float,h:Float,geometry:String,vertices:String){
        if(geometry=="point")canvas.drawCircle(xToScreen(x),yToScreen(y),10f,paint)
        else if(geometry=="polygon") {
            try { val a=JSONArray(vertices); val path=Path();for(i in 0 until a.length()){
                val item=a.getJSONArray(i);val px=xToScreen(item.getDouble(0).toFloat());val py=yToScreen(item.getDouble(1).toFloat())
                if(i==0)path.moveTo(px,py) else path.lineTo(px,py)
            };path.close();canvas.drawPath(path,paint) }catch (_:Exception){}
        } else canvas.drawRect(xToScreen(x),yToScreen(y),xToScreen(x+w),yToScreen(y+h),paint)
    }
    override fun onTouchEvent(event:MotionEvent):Boolean {
        scaleDetector.onTouchEvent(event)
        if(event.pointerCount>=2){moved=true;return true}
        when(event.actionMasked){
            MotionEvent.ACTION_DOWN->{ startX=event.x;startY=event.y;fingerX=event.x;fingerY=event.y;moved=false
                selected=notes.lastOrNull{ xToImage(event.x)>=it.x&&xToImage(event.x)<=it.x+max(it.w,.02f)&&yToImage(event.y)>=it.y&&yToImage(event.y)<=it.y+max(it.h,.02f) }
                isDrawing=tool==Tool.RECT;invalidate();return true }
            MotionEvent.ACTION_MOVE->{
                if(abs(event.x-startX)>8||abs(event.y-startY)>8)moved=true
                if(tool==Tool.PAN || (tool==Tool.MOVE && selected==null)) {panX+=event.x-fingerX;panY+=event.y-fingerY}
                fingerX=event.x;fingerY=event.y;invalidate();return true
            }
            MotionEvent.ACTION_UP->{
                when(tool) {
                    Tool.RECT->{if(moved&&abs(event.x-startX)>12&&abs(event.y-startY)>12){
                        val x1=xToImage(startX);val x2=xToImage(event.x);val y1=yToImage(startY);val y2=yToImage(event.y)
                        onMark?.invoke(Mark(min(x1,x2),min(y1,y2),abs(x1-x2),abs(y1-y2),"rect"))
                    }}
                    Tool.POINT -> onMark?.invoke(Mark(xToImage(event.x),yToImage(event.y),0f,0f,"point"))
                    Tool.POLYGON -> polygon.add(xToImage(event.x) to yToImage(event.y))
                    Tool.MOVE->{val n=selected;if(n!=null){val dx=xToImage(event.x)-xToImage(startX);val dy=yToImage(event.y)-yToImage(startY)
                        val movedVertices=if(n.geometry=="polygon") try {val a=JSONArray(n.vertices);JSONArray().apply{for(i in 0 until a.length()){
                            val pair=a.getJSONArray(i);put(JSONArray().put((pair.getDouble(0)+dx).coerceIn(0.0,1.0)).put((pair.getDouble(1)+dy).coerceIn(0.0,1.0)))
                        }}.toString()}catch (_:Exception){n.vertices} else n.vertices
                        onNoteMove?.invoke(n.copy(x=(n.x+dx).coerceIn(0f,1f),y=(n.y+dy).coerceIn(0f,1f),vertices=movedVertices))
                    }}
                    Tool.PAN-> if(!moved)selected?.let{onNoteClick?.invoke(it)}
                }
                isDrawing=false;invalidate();return true
            }
        }
        return true
    }
    override fun onDetachedFromWindow(){super.onDetachedFromWindow();decoder?.recycle();decoder=null;cachedTile?.recycle();cachedTile=null}
}
