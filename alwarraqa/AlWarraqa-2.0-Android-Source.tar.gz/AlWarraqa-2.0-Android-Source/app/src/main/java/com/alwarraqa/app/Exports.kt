package com.alwarraqa.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min

object Exports {
    private fun xml(x:String):String = x.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
    private fun csv(x:String)="\""+x.replace("\"","\"\"").replace("\r"," ").replace("\n"," ")+"\""
    private fun pagesById(store: Store,p:Project)=store.pages(p.id).associateBy{it.id}
    private fun rows(store:Store,p:Project)=store.notesForProject(p.id).map{it to pagesById(store,p)[it.pageId]}
    fun json(store:Store,p:Project):ByteArray {
        val o=JSONObject().apply { put("schema","alwarraqa:2.0");put("exported",System.currentTimeMillis())
            put("project",JSONObject().apply{put("id",p.id);put("title",p.title);put("library",p.library);put("shelfmark",p.shelfmark);put("author",p.author);put("work",p.work)})
        }
        o.put("pages",JSONArray().apply{store.pages(p.id).forEach { page->put(JSONObject().apply {
            put("id",page.id);put("name",page.name);put("folio",page.folio);put("side",page.side);put("sha256",page.sha256);put("iiif",page.iiif)
        }) } })
        o.put("notes",JSONArray().apply{store.notesForProject(p.id).forEach{put(noteJson(it))}})
        o.put("relations",JSONArray().apply{
            store.notesForProject(p.id).flatMap { store.relations(it.id) }.distinctBy { it.id }.forEach { r -> put(JSONObject().apply {
                put("source",r.sourceNoteId);put("target",r.targetNoteId);put("type",r.type);put("rationale",r.rationale)
            }) }
        })
        return o.toString(2).toByteArray(Charsets.UTF_8)
    }
    fun csv(store:Store,p:Project):ByteArray {
        val header=listOf("uuid","manuscript","library","shelfmark","page","folio","category","title","observation","reading","interpretation","confidence","references","researcher","geometry","x","y","w","h","vertices","image_sha256")
        val lines=mutableListOf(header.joinToString(","))
        rows(store,p).forEach{(n,page)->
            lines+= listOf(n.uuid,p.title,p.library,p.shelfmark,page?.name?:"",page?.folio?:"",n.category,n.title,n.observation,n.reading,n.interpretation,n.confidence,n.references,n.researcher,n.geometry,n.x.toString(),n.y.toString(),n.w.toString(),n.h.toString(),n.vertices,page?.sha256?:"").joinToString(",",transform=::csv)
        }
        return ("\uFEFF"+lines.joinToString("\r\n")).toByteArray(Charsets.UTF_8)
    }
    private fun ZipOutputStream.write(name:String,bytes:ByteArray){putNextEntry(ZipEntry(name));write(bytes);closeEntry()}
    private fun xlsxSheet(store:Store,p:Project):String {
        val items=String(csv(store,p),Charsets.UTF_8).removePrefix("\uFEFF").lineSequence().toList()
        // Read directly from domain objects; don't reparse CSV with embedded commas.
        val lines=mutableListOf(listOf("UUID","المخطوط","الورقة","التصنيف","عنوان الشاهد","المشاهدة","القراءة","التفسير","اليقين","المراجع","الباحث","الشكل","X","Y","W","H"))
        rows(store,p).forEach{ (n,page)-> lines+= listOf(n.uuid,p.title,page?.name?:"",n.category,n.title,n.observation,n.reading,n.interpretation,n.confidence,n.references,n.researcher,n.geometry,n.x.toString(),n.y.toString(),n.w.toString(),n.h.toString()) }
        return buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"/></sheetViews><sheetData>")
            lines.forEachIndexed{ r,row->append("<row r=\"${r+1}\">");row.forEachIndexed{col,v->
                var idx=col+1;var letter="";while(idx>0){idx--;letter=('A'+idx%26)+letter;idx/=26}
                append("<c r=\"$letter${r+1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xml(v)}</t></is></c>")
            };append("</row>")};append("</sheetData></worksheet>")
        }
    }
    fun xlsx(store:Store,p:Project):ByteArray {
        val out=ByteArrayOutputStream();ZipOutputStream(out).use{z->
            z.write("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""".toByteArray())
            z.write("_rels/.rels", """<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""".toByteArray())
            z.write("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="الشواهد" sheetId="1" r:id="rId1"/></sheets></workbook>""".toByteArray())
            z.write("xl/_rels/workbook.xml.rels", """<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""".toByteArray())
            z.write("xl/worksheets/sheet1.xml",xlsxSheet(store,p).toByteArray())
        };return out.toByteArray()
    }
    private fun cropped(page:Page?,note:Note):ByteArray? {
        if(page==null || page.path.startsWith("http"))return null
        val file=File(page.path);if(!file.isFile)return null
        return try {
            @Suppress("DEPRECATION") val decoder=BitmapRegionDecoder.newInstance(file.path,false)
            val width=decoder.width;val height=decoder.height
            val padding=.015f
            val left=((note.x-padding).coerceIn(0f,.999f)*width).toInt(); val top=((note.y-padding).coerceIn(0f,.999f)*height).toInt()
            val right=(((note.x+max(note.w,.06f)+padding).coerceIn(0.001f,1f))*width).toInt().coerceAtLeast(left+1)
            val bottom=(((note.y+max(note.h,.04f)+padding).coerceIn(.001f,1f))*height).toInt().coerceAtLeast(top+1)
            var sampling=1;while(max((right-left)/sampling,(bottom-top)/sampling)>1300)sampling*=2
            val bitmap=decoder.decodeRegion(Rect(left,top,right,bottom),BitmapFactory.Options().apply { inSampleSize=sampling })
            val out=ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.PNG,95,out)
            bitmap.recycle();decoder.recycle();out.toByteArray()
        }catch (_:Exception){null}
    }
    fun pdf(store:Store,p:Project):ByteArray {
        val pdf=PdfDocument();val body=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;textSize=15f}
        val title=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(16,83,112);textSize=23f;isFakeBoldText=true}
        fun line(c:Canvas,s:String,y:Float,x:Float=790f,maxChars:Int=88) {
            val txt=s.take(maxChars)
            c.drawText(txt,x-body.measureText(txt),y,body)
        }
        rows(store,p).forEachIndexed{index,(n,page)->
            val info=PdfDocument.PageInfo.Builder(842,1191,index+1).create();val pg=pdf.startPage(info);val c=pg.canvas
            c.drawColor(Color.WHITE);c.drawText("الورّاقة — ${p.title.take(55)}",790f-title.measureText("الورّاقة — ${p.title.take(55)}"),65f,title)
            line(c,"المكتبة: ${p.library}  |  رقم الحفظ: ${p.shelfmark}",110f)
            line(c,"الورقة: ${page?.folio?.ifBlank{page.name} ?: ""}   |   نوع الشاهد: ${n.category}",145f)
            line(c,"عنوان الشاهد: ${n.title}",180f)
            cropped(page,n)?.let{ b->
                val bmp=BitmapFactory.decodeByteArray(b,0,b.size);if(bmp!=null){
                    val scale=min(730f/bmp.width,390f/bmp.height);val w=bmp.width*scale;val h=bmp.height*scale
                    c.drawBitmap(bmp,null,RectF((842-w)/2,208f,(842+w)/2,208f+h),null);bmp.recycle()
                }
            }
            val sections=listOf("المشاهدة" to n.observation,"القراءة" to n.reading,"التفسير" to n.interpretation,"درجة اليقين" to n.confidence,"المصادر" to n.references,"الباحث" to n.researcher)
            var y=655f
            for((heading,value) in sections){if(value.isNotBlank()){
                line(c,"$heading:",y)
                value.chunked(72).take(4).forEach { chunk->y+=25;line(c,chunk,y) };y+=27
            }}
            line(c,"المعرّف: ${n.uuid}  •  ${index+1}",1155f)
            pdf.finishPage(pg)
        }
        if(rows(store,p).isEmpty()){
            val pg=pdf.startPage(PdfDocument.PageInfo.Builder(842,1191,1).create());pg.canvas.drawText("الورّاقة — ${p.title}",60f,90f,title);pdf.finishPage(pg)
        }
        val out=ByteArrayOutputStream();pdf.writeTo(out);pdf.close();return out.toByteArray()
    }
    private fun paragraph(s:String,bold:Boolean=false)="<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:rPr><w:rtl/>"+(if(bold)"<w:b/>" else "")+"</w:rPr><w:t xml:space=\"preserve\">${xml(s)}</w:t></w:r></w:p>"
    fun docx(store:Store,p:Project):ByteArray {
        val out=ByteArrayOutputStream();val rels=StringBuilder();val media=mutableMapOf<String,ByteArray>()
        val content=buildString {
            append(paragraph("الورّاقة — ${p.title}",true));append(paragraph("المكتبة: ${p.library} — رقم الحفظ: ${p.shelfmark}"))
            rows(store,p).forEachIndexed{index,(n,page)->
                append(paragraph("الشاهد ${index+1}: ${n.title} (${n.category})",true))
                append(paragraph("الورقة: ${page?.folio?.ifBlank{page.name}?:""}"))
                cropped(page,n)?.let {bytes->
                    val id="rId${index+1}";media["word/media/crop${index+1}.png"]=bytes
                    rels.append("<Relationship Id=\"$id\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/crop${index+1}.png\"/>")
                    append("""<w:p><w:r><w:drawing><wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"><wp:extent cx="4700000" cy="2600000"/><wp:docPr id="${index+1}" name="Crop"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="0" name="Crop"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="$id"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="4700000" cy="2600000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>""")
                }
                append(paragraph("المشاهدة: ${n.observation}"));append(paragraph("القراءة: ${n.reading}"));append(paragraph("التفسير: ${n.interpretation}"));append(paragraph("اليقين: ${n.confidence}"));append(paragraph("المصادر: ${n.references}"));append(paragraph("الباحث: ${n.researcher}"));append(paragraph("المعرف: ${n.uuid}"))
            }
        }
        ZipOutputStream(out).use{z->
            z.write("[Content_Types].xml",("""<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>""").toByteArray())
            z.write("_rels/.rels","""<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>""".toByteArray())
            z.write("word/_rels/document.xml.rels",("""<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$rels</Relationships>""").toByteArray())
            z.write("word/document.xml",("""<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$content<w:sectPr/></w:body></w:document>""").toByteArray())
            media.forEach{(k,v)->z.write(k,v)}
        };return out.toByteArray()
    }
    fun mime(type:String)=when(type){"pdf"->"application/pdf";"docx"->"application/vnd.openxmlformats-officedocument.wordprocessingml.document";"xlsx"->"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";"json"->"application/json";"zip"->"application/zip";else->"text/csv"}
    fun export(type:String,store:Store,p:Project)=when(type){"pdf"->pdf(store,p);"docx"->docx(store,p);"xlsx"->xlsx(store,p);"json"->json(store,p);else->csv(store,p)}
}

object Backup {
    private fun sha256(bytes:ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(""){"%02x".format(it)}
    fun sha256File(file:File):String = MessageDigest.getInstance("SHA-256").let{d->file.inputStream().use{ins->val buf=ByteArray(8192);while(true){val n=ins.read(buf);if(n<0)break;d.update(buf,0,n)}};d.digest().joinToString(""){"%02x".format(it)}}
    /** Backup contains db and every internal image. Integrity manifest allows verification before restore. */
    fun create(context:Context,store:Store,out:OutputStream) {
        store.checkpoint();store.close()
        val items=mutableListOf<Pair<String,File>>()
        val db=context.getDatabasePath("warraqa.db");if(db.isFile)items+=("database/warraqa.db" to db)
        val imageRoot=File(context.filesDir,"images")
        imageRoot.walkTopDown().filter{it.isFile}.forEach {items+=("images/"+it.relativeTo(imageRoot).invariantSeparatorsPath to it)}
        val manifest=JSONObject().apply{put("schema",2);put("generated",System.currentTimeMillis());put("files",JSONArray().apply{
            items.forEach{(name,file)->put(JSONObject().apply {put("path",name);put("sha256",sha256File(file));put("size",file.length())})}
        })}
        ZipOutputStream(out).use{z->items.forEach { (name,file)->z.putNextEntry(ZipEntry(name));file.inputStream().use{it.copyTo(z)};z.closeEntry() }
            z.putNextEntry(ZipEntry("manifest.json"));z.write(manifest.toString(2).toByteArray());z.closeEntry()
        }
    }
    /** Verifies every byte and enforces a fixed allowlist before replacing anything. Call only after explicit user choice. */
    fun restore(context:Context,input:InputStream):String {
        val temp=File(context.cacheDir,"restore_${System.currentTimeMillis()}").apply{mkdirs()}
        try {
            ZipInputStream(input).use{z->var entries=0;var total=0L
                while(true){val entry=z.nextEntry?:break;entries++;require(entries<=20000){"Too many entries"}
                    val name=entry.name.replace('\\','/');require(name=="manifest.json"||name=="database/warraqa.db"||name.startsWith("images/")) { "Unknown entry: $name" }
                    require(!name.split('/').contains("..")&&!name.startsWith("/")){"Unsafe path"}
                    if(!entry.isDirectory){val dst=File(temp,name).canonicalFile;require(dst.path.startsWith(temp.canonicalPath+File.separator)){"Unsafe path"}
                        dst.parentFile?.mkdirs();dst.outputStream().use{out->val b=ByteArray(8192);while(true){val n=z.read(b);if(n<0)break;total+=n;require(total<=2_000_000_000){"Backup too large"};out.write(b,0,n)}}
                    };z.closeEntry()
                }
            }
            val manifest=JSONObject(File(temp,"manifest.json").readText())
            if(!manifest.has("schema") || manifest.optInt("schema")==1){
                val (projects,notes)=LegacyImporter.import(context,temp,manifest)
                return "تم استيراد $projects مشروعًا و$notes شاهدًا من النسخة القديمة؛ دون حذف البيانات الحالية."
            }
            require(manifest.getInt("schema")==2){"Wrong backup schema"}
            val array=manifest.getJSONArray("files"); val allowed=mutableSetOf<String>()
            for(i in 0 until array.length()) {val info=array.getJSONObject(i);val name=info.getString("path");val f=File(temp,name)
                require(f.isFile && f.length()==info.getLong("size") && sha256File(f)==info.getString("sha256")){"Integrity mismatch: $name"};allowed+=name
            }
            require(File(temp,"database/warraqa.db").isFile){"Missing database"}
            val actual=temp.walkTopDown().filter{it.isFile&&it.name!="manifest.json"}.map{it.relativeTo(temp).invariantSeparatorsPath}.toSet()
            require(actual==allowed){"Unlisted entries"}
            val db=File(temp,"database/warraqa.db")
            // SQLite integrity check before replacing current data.
            val check=android.database.sqlite.SQLiteDatabase.openDatabase(db.path,null,android.database.sqlite.SQLiteDatabase.OPEN_READONLY)
            try {check.rawQuery("PRAGMA integrity_check",null).use{c->require(c.moveToFirst()&&c.getString(0)=="ok"){"Corrupt database"}}} finally {check.close()}
            val original=context.getDatabasePath("warraqa.db");original.parentFile?.mkdirs()
            val rescue=File(context.filesDir,"restore_previous_db_${System.currentTimeMillis()}.db")
            if(original.isFile)original.copyTo(rescue)
            File(original.path+"-wal").delete();File(original.path+"-shm").delete()
            db.copyTo(original,overwrite=true)
            File(context.filesDir,"images").mkdirs()
            File(temp,"images").takeIf{it.isDirectory}?.walkTopDown()?.filter{it.isFile}?.forEach{f->
                val dest=File(context.filesDir,"images/"+f.relativeTo(File(temp,"images")).invariantSeparatorsPath)
                dest.parentFile?.mkdirs();f.copyTo(dest,overwrite=true)
            }
            // Repair paths when a backup is restored into a different Android user/profile.
            val checkDb=android.database.sqlite.SQLiteDatabase.openDatabase(original.path,null,android.database.sqlite.SQLiteDatabase.OPEN_READWRITE)
            try {val rewrites=mutableListOf<Pair<Long,String>>()
                checkDb.rawQuery("SELECT id,path FROM pages WHERE path NOT LIKE 'https://%'",null).use{c->
                    while(c.moveToNext()){
                        val path=c.getString(1);val local=File(context.filesDir,"images/"+File(path).name)
                        if(!File(path).isFile&&local.isFile)rewrites+=(c.getLong(0) to local.path)
                    }
                }
                rewrites.forEach{(id,path)->checkDb.execSQL("UPDATE pages SET path=? WHERE id=?",arrayOf(path,id))}
            } finally{checkDb.close()}
        } finally {temp.deleteRecursively()}
        // Caller must restart the process so SQLiteOpenHelper cannot keep an old connection.
        return "تمت استعادة النسخة. أغلق التطبيق وأعد فتحه."
    }
}
