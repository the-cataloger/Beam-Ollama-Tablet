package com.alwarraqa.app

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.UUID

private val teal=Color(0xFF087E83)
private val paper=Color(0xFFF6F4EE)
private val categories=listOf("خط","تملك","سماع","إجازة","وقف","تصحيح","مقابلة","حاشية","زخرفة","رسم","ختم","تجليد","تقييد","أخرى")
class MainActivity:ComponentActivity() {
    private lateinit var store:Store
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState);store=Store(this)
        setContent { MaterialTheme(colorScheme=lightColorScheme(primary=teal,background=paper,surface=Color.White)) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){ Workbench(store) }
        } }
    }
    override fun onDestroy(){store.close();super.onDestroy()}
}

@Composable private fun Workbench(store:Store) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    var currentProject by remember{mutableStateOf<Project?>(null)}
    var currentPage by remember{mutableStateOf<Page?>(null)}
    var projectDialog by remember{mutableStateOf<Project?>(null)}
    var pageDialog by remember{mutableStateOf<Page?>(null)}
    var newProject by remember{mutableStateOf(false)}
    var draftMark by remember{mutableStateOf<Mark?>(null)}
    var selectedNote by remember{mutableStateOf<Note?>(null)}
    var relationNote by remember{mutableStateOf<Note?>(null)}
    var historyNote by remember{mutableStateOf<Note?>(null)}
    var showIIIF by remember{mutableStateOf(false)}
    var showRestore by remember{mutableStateOf(false)}
    var compareMode by remember{mutableStateOf(false)}
    var comparePage by remember{mutableStateOf<Page?>(null)}
    var tool by remember{mutableStateOf(Tool.PAN)}
    var search by remember{mutableStateOf("")}
    var view by remember{mutableStateOf<ManuscriptView?>(null)}
    var exportType by remember{mutableStateOf("pdf")}
    var message by remember{mutableStateOf("")}
    fun notify(msg:String){message=msg;Toast.makeText(context,msg,Toast.LENGTH_LONG).show()}
    val projects=remember(refresh){store.projects()}
    val project=currentProject?.let {p->projects.firstOrNull{it.id==p.id}?:p}
    val pages=remember(refresh,project?.id){project?.let{store.pages(it.id)}?:emptyList()}
    val page=currentPage?.let {c->pages.firstOrNull{it.id==c.id}?:c}
    val pageNotes=remember(refresh,page?.id){page?.let{store.notes(it.id)}?:emptyList()}
    val allNotes=remember(refresh,project?.id){project?.let{store.notesForProject(it.id)}?:emptyList()}
    val filtered=remember(search,allNotes){if(search.isBlank())pageNotes else project?.let{store.search(it.id,search)}?:emptyList()}
    val pick=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris->
        val p=project?:return@rememberLauncherForActivityResult
        scope.launch { try { withContext(Dispatchers.IO){
            uris.forEachIndexed {i,uri->
                val ext=context.contentResolver.getType(uri)?.let{if(it.contains("png"))"png" else if(it.contains("webp"))"webp" else "jpg"}?:"jpg"
                val file=File(context.filesDir,"images/${UUID.randomUUID()}.$ext");file.parentFile?.mkdirs()
                context.contentResolver.openInputStream(uri)?.use{input->file.outputStream().use{input.copyTo(it)}}
                if(file.length()>0)store.addPage(p.id,"ورقة ${pages.size+i+1}",file.absolutePath,Backup.sha256File(file))
            }
        };refresh++;notify("تم استيراد ${uris.size} صورة") }catch(e:Exception){notify("تعذر الاستيراد: ${e.message}")} }
    }
    val saveFile=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) {uri:Uri?->
        val p=project?:return@rememberLauncherForActivityResult
        if(uri!=null)scope.launch {try{withContext(Dispatchers.IO){
            val bytes=Exports.export(exportType,store,p)
            context.contentResolver.openOutputStream(uri)?.use{it.write(bytes)} ?:error("Unable to open output")
        };notify("تم تصدير $exportType") }catch(e:Exception){notify("فشل التصدير: ${e.message}")} }
    }
    val backupLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri:Uri?->
        if(uri!=null)scope.launch{try{withContext(Dispatchers.IO){context.contentResolver.openOutputStream(uri)?.use{Backup.create(context,store,it)}};notify("تم حفظ النسخة الاحتياطية")
        }catch(e:Exception){notify("فشل النسخ الاحتياطي: ${e.message}")} }
    }
    val restoreLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri:Uri?->
        if(uri!=null)scope.launch {try{withContext(Dispatchers.IO){store.checkpoint();store.close();context.contentResolver.openInputStream(uri)?.use{Backup.restore(context,it)}}
            refresh++;currentProject=null;currentPage=null;notify("تمت الاستعادة. أغلق التطبيق تمامًا وافتحه مجددًا لتحديث البيانات.")
        }catch(e:Exception){notify("فشل الاسترجاع: ${e.message}")} }
    }
    Column(Modifier.fillMaxSize().background(paper)) {
        Surface(color=Color(0xFF102B38),tonalElevation=4.dp) {
            Row(Modifier.fillMaxWidth().padding(8.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                Text("الوَرّاقة",Modifier.padding(horizontal=9.dp),color=Color.White,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)
                if(project!=null) {
                    TextButton(onClick={currentProject=null;currentPage=null}){Text("المشروعات",color=Color.White)}
                    Text(project.title,Modifier.weight(1f),color=Color.White,maxLines=1,overflow=TextOverflow.Ellipsis)
                } else Spacer(Modifier.weight(1f))
                if(project!=null) {
                    TextButton(onClick={projectDialog=project}){Text("بيانات المخطوط",color=Color.White)}
                    TextButton(onClick={backupLauncher.launch("AlWarraqa-backup.zip")}){Text("نسخ احتياطي",color=Color.White)}
                }
                TextButton(onClick={showRestore=true}){Text("استعادة",color=Color.White)}
            }
        }
        if(project==null) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically){Text("المشروعات البحثية",Modifier.weight(1f),style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
                    Button(onClick={newProject=true}){Text("+ مشروع جديد")}}
                Spacer(Modifier.height(16.dp))
                LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)) {
                    items(projects,key={it.id}){p->Card(Modifier.fillMaxWidth().clickable {currentProject=p;currentPage=null}){
                        Column(Modifier.padding(20.dp)){
                            Text(p.title,style=MaterialTheme.typography.titleLarge,color=teal)
                            Text(listOf(p.library,p.shelfmark).filter{it.isNotBlank()}.joinToString(" — "),color=Color.Gray)
                            Text("${store.pages(p.id).size} صور  |  ${store.notesForProject(p.id).size} شواهد",style=MaterialTheme.typography.bodySmall)
                        }
                    }}
                }
                if(projects.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("أنشئ مشروعًا، ثم أضف صور المخطوط وابدأ توثيق الشواهد.")}
            }
        }else{
            Column(Modifier.fillMaxSize().padding(horizontal=8.dp)) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical=6.dp),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically) {
                    Button(onClick={pick.launch(arrayOf("image/*"))}){Text("+ صور محلية")}
                    OutlinedButton(onClick={showIIIF=true}){Text("استيراد IIIF")}
                    listOf("pdf","docx","xlsx","csv","json").forEach { format->
                        OutlinedButton(onClick={exportType=format;saveFile.launch("AlWarraqa-${project.title.take(22)}.$format")}){Text(format.uppercase())}
                    }
                    OutlinedButton(onClick={backupLauncher.launch("AlWarraqa-backup.zip")}){Text("ZIP")}
                    OutlinedButton(onClick={compareMode=!compareMode}){Text(if(compareMode)"إغلاق المقارنة" else "مقارنة نسختين")}
                }
                OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth().height(58.dp),placeholder={Text("بحث عربي في الشواهد والمشاهدات والقراءات...")},singleLine=true)
                LazyRow(Modifier.fillMaxWidth().padding(vertical=5.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    items(pages,key={it.id}){p->
                        FilterChip(selected=page?.id==p.id,onClick={currentPage=p},label={Text(p.folio.ifBlank{p.name})})
                    }
                }
                if(page==null) {Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
                    Text("اختر ورقة أو استورد صورة لإظهار مستعرض الشواهد.",textAlign=TextAlign.Center)
                }}else{
                    BoxWithConstraints(Modifier.fillMaxSize()){
                        val wide=maxWidth>850.dp
                        if(wide)Row(Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                            PagePanel(page,Modifier.width(190.dp),onEdit={pageDialog=page})
                            ViewerPanel(page,pageNotes,tool,compareMode,comparePage,Modifier.weight(1.5f),onViewer={view=it},onMark={draftMark=it},onClickNote={selectedNote=it},onMoved={store.saveNote(it);refresh++})
                            NotePanel(filtered,allNotes,Modifier.weight(1f),onEdit={selectedNote=it},onRelations={relationNote=it},onHistory={historyNote=it})
                        } else Column(Modifier.fillMaxSize()) {
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(page.folio.ifBlank{page.name},fontWeight=FontWeight.Bold)
                                TextButton(onClick={pageDialog=page}){Text("تحرير بيانات الورقة")}}
                            ViewerPanel(page,pageNotes,tool,compareMode,comparePage,Modifier.weight(1f),onViewer={view=it},onMark={draftMark=it},onClickNote={selectedNote=it},onMoved={store.saveNote(it);refresh++})
                            NotePanel(filtered,allNotes,Modifier.fillMaxWidth().heightIn(max=220.dp),onEdit={selectedNote=it},onRelations={relationNote=it},onHistory={historyNote=it})
                        }
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        Tool.entries.forEach{t->FilterChip(selected=tool==t,onClick={tool=t;view?.tool=t},label={Text(when(t){Tool.PAN->"تحريك/تكبير";Tool.RECT->"مستطيل";Tool.POLYGON->"مضلع";Tool.POINT->"نقطة";Tool.MOVE->"نقل تحديد"})})}
                        Button(enabled=tool==Tool.POLYGON,onClick={view?.finishPolygon()}){Text("إغلاق المضلع")}
                        if(compareMode){var showList by remember{mutableStateOf(false)};Box {
                            OutlinedButton(onClick={showList=true}){Text("النسخة المقارنة: ${comparePage?.name?:"اختر"}")}
                            DropdownMenu(expanded=showList,onDismissRequest={showList=false}){pages.filter{it.id!=page.id}.forEach{p->DropdownMenuItem(text={Text(p.name)},onClick={comparePage=p;showList=false})}}
                        }}
                    }
                }
            }
        }
    }
    if(newProject){ var title by remember{mutableStateOf("")};AlertDialog(onDismissRequest={newProject=false},title={Text("مشروع مخطوط جديد")},text={
        OutlinedTextField(title,{title=it},label={Text("عنوان المشروع / المخطوط")})
    },confirmButton={TextButton(enabled=title.isNotBlank(),onClick={val id=store.createProject(title);currentProject=store.projects().first{it.id==id};newProject=false;refresh++}){Text("إنشاء")}},dismissButton={TextButton(onClick={newProject=false}){Text("إلغاء")}})}
    projectDialog?.let {p->ProjectDialog(p,onDismiss={projectDialog=null},onSave={store.updateProject(it);currentProject=it;projectDialog=null;refresh++})}
    pageDialog?.let{p->PageDialog(p,onDismiss={pageDialog=null},onSave={store.updatePage(it);pageDialog=null;refresh++})}
    if(showIIIF && project!=null) {
        var url by remember {mutableStateOf("")}
        var busy by remember {mutableStateOf(false)}
        AlertDialog(onDismissRequest={if(!busy)showIIIF=false},title={Text("استيراد بيان IIIF")},text={Column{
            Text("يدعم بيانات العرض Manifest من IIIF Presentation 2 و3. يلزم رابط HTTPS.")
            OutlinedTextField(url,{url=it},label={Text("رابط Manifest")},minLines=2)
        }},confirmButton={TextButton(enabled=!busy&&url.startsWith("https://"),onClick={busy=true;scope.launch{
            try{val found=withContext(Dispatchers.IO){IIIF.importManifest(url)}
                withContext(Dispatchers.IO){found.forEach {c->store.addPage(project.id,c.label,c.imageUrl,iiif=c.canvasId)}}
                refresh++;notify("تم إدراج ${found.size} ورقة من IIIF");showIIIF=false
            }catch(e:Exception){notify("تعذر قراءة IIIF: ${e.message}")}finally{busy=false}
        }}){Text(if(busy)"جارٍ الاستيراد" else "استيراد")}},dismissButton={TextButton(onClick={showIIIF=false}){Text("إلغاء")}})
    }
    if(showRestore)AlertDialog(onDismissRequest={showRestore=false},title={Text("استعادة نسخة احتياطية")},text={Text("سيتم فحص سلامة ملفات ZIP. الاستعادة تستبدل قاعدة بيانات العمل الحالية، ويُحتفظ بنسخة إنقاذ محلية. احفظ نسخة احتياطية أولًا؛ يلزم إعادة تشغيل التطبيق.")},confirmButton={TextButton(onClick={showRestore=false;restoreLauncher.launch(arrayOf("application/zip"))}){Text("اختيار ملف الاستعادة")}},dismissButton={TextButton(onClick={showRestore=false}){Text("إلغاء")}})
    if(draftMark!=null&&page!=null){NoteDialog(null,page.id,draftMark!!,onDismiss={draftMark=null},onSave={store.saveNote(it);draftMark=null;refresh++},onDelete=null)}
    selectedNote?.let{n->NoteDialog(n,n.pageId,Mark(n.x,n.y,n.w,n.h,n.geometry,n.vertices),onDismiss={selectedNote=null},onSave={store.saveNote(it);selectedNote=null;refresh++},onDelete={store.deleteNote(n.id);selectedNote=null;refresh++})}
    relationNote?.let{n->RelationDialog(n,allNotes,store.relations(n.id),onDismiss={relationNote=null},onAdd={target,type,why->try{store.link(n.id,target,type,why);refresh++;relationNote=null}catch(e:Exception){notify(e.message?:"خطأ")}})}
    historyNote?.let{n->val versions=store.oldVersions(n.id);AlertDialog(onDismissRequest={historyNote=null},title={Text("سجل التعديلات: ${n.title}")},text={Column(Modifier.heightIn(max=350.dp).verticalScroll(rememberScrollState())){
        if(versions.isEmpty())Text("لا توجد نسخ سابقة")
        versions.forEachIndexed{idx,v->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)) {Column(Modifier.padding(10.dp)){
            Text("مراجعة ${idx+1}: ${v.optString("title")}")
            Text(v.optString("observation").take(140),style=MaterialTheme.typography.bodySmall)
            TextButton(onClick={store.saveNote(n.copy(title=v.optString("title"),observation=v.optString("observation"),reading=v.optString("reading"),interpretation=v.optString("interpretation"),confidence=v.optString("confidence"),category=v.optString("category"),references=v.optString("references")));historyNote=null;refresh++}){Text("استعادة هذه النسخة")}
        }}}
    }},confirmButton={TextButton(onClick={historyNote=null}){Text("إغلاق")}})}
}

@Composable private fun PagePanel(page:Page,modifier:Modifier,onEdit:()->Unit) {
    Card(modifier.fillMaxHeight()) {Column(Modifier.padding(14.dp)){
        Text("بيانات الورقة",fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(9.dp));Text(page.name);Text("رقم الورقة: ${page.folio}")
        Text("الوجه: ${page.side}");Text("SHA-256: ${page.sha256.take(15)}…",style=MaterialTheme.typography.bodySmall)
        if(page.iiif.isNotBlank())Text("IIIF: ${page.iiif.take(30)}",style=MaterialTheme.typography.bodySmall)
        TextButton(onClick=onEdit){Text("تعديل البيانات")}
    }}
}
@Composable private fun ViewerPanel(page:Page,notes:List<Note>,tool:Tool,compareMode:Boolean,comparePage:Page?,modifier:Modifier,
    onViewer:(ManuscriptView)->Unit,onMark:(Mark)->Unit,onClickNote:(Note)->Unit,onMoved:(Note)->Unit) {
    val context=LocalContext.current
    var imagePath by remember(page.id){mutableStateOf<String?>(null)}
    var comparePath by remember(comparePage?.id){mutableStateOf<String?>(null)}
    LaunchedEffect(page.path){imagePath=try {withContext(Dispatchers.IO){if(page.path.startsWith("https://"))IIIF.cacheImage(context,page.path).path else page.path}}catch(_:Exception){null}}
    LaunchedEffect(comparePage?.path){comparePath=comparePage?.let{try{withContext(Dispatchers.IO){if(it.path.startsWith("https://"))IIIF.cacheImage(context,it.path).path else it.path}}catch(_:Exception){null}}}
    Row(modifier,horizontalArrangement=Arrangement.spacedBy(4.dp)) {
        ImageSlot(page,imagePath,1f,true,notes,tool,onViewer,onMark,onClickNote,onMoved)
        if(compareMode&&comparePage!=null) ImageSlot(comparePage,comparePath,1f,false,emptyList(),Tool.PAN,onViewer,onMark,onClickNote,onMoved)
    }
}
@Composable private fun RowScope.ImageSlot(p:Page?,path:String?,weight:Float,active:Boolean,notes:List<Note>,tool:Tool,
   onViewer:(ManuscriptView)->Unit,onMark:(Mark)->Unit,onClickNote:(Note)->Unit,onMoved:(Note)->Unit) {
    Box(Modifier.weight(weight).fillMaxHeight().background(Color(0xFF17232A)),contentAlignment=Alignment.Center){
        if(p!=null&&path!=null&&File(path).isFile){key(p.id,path){
            AndroidView(factory={ctx->ManuscriptView(ctx).also{it.load(File(path));if(active)onViewer(it)}},modifier=Modifier.fillMaxSize(),update={v->
                v.tool=if(active)tool else Tool.PAN;v.notes=if(active)notes else emptyList()
                v.onMark=if(active)onMark else null;v.onNoteClick=if(active)onClickNote else null;v.onNoteMove=if(active)onMoved else null
            })
        }}else Text("تعذر تحميل الصورة",color=Color.White)
    }
}
@Composable private fun NotePanel(notes:List<Note>,allNotes:List<Note>,modifier:Modifier,onEdit:(Note)->Unit,onRelations:(Note)->Unit,onHistory:(Note)->Unit) {
    Card(modifier) {Column(Modifier.fillMaxSize().padding(7.dp)){
        Text("سجل الشواهد (${notes.size})",fontWeight=FontWeight.Bold,modifier=Modifier.padding(7.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(5.dp)) {
            items(notes,key={it.id}) {n->Surface(shape=RoundedCornerShape(10.dp),color=Color(0xFFEFF5F3),modifier=Modifier.fillMaxWidth().clickable{onEdit(n)}){
                Column(Modifier.padding(10.dp)){
                    Row {Text(n.title.ifBlank{"شاهد ${n.id}"},Modifier.weight(1f),fontWeight=FontWeight.SemiBold,maxLines=1);Text(n.category,color=teal)}
                    Text(n.observation.take(115),maxLines=2,overflow=TextOverflow.Ellipsis,style=MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick={onEdit(n)}){Text("تحرير")}
                        TextButton(onClick={onRelations(n)}){Text("العلاقات")}
                        TextButton(onClick={onHistory(n)}){Text("التاريخ")}
                    }
                }
            }}
        }
    }}
}
@Composable private fun ProjectDialog(p:Project,onDismiss:()->Unit,onSave:(Project)->Unit){
    var title by remember(p.id){mutableStateOf(p.title)};var desc by remember(p.id){mutableStateOf(p.description)}
    var library by remember(p.id){mutableStateOf(p.library)};var shelfmark by remember(p.id){mutableStateOf(p.shelfmark)}
    var author by remember(p.id){mutableStateOf(p.author)};var work by remember(p.id){mutableStateOf(p.work)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("بيانات المخطوط والمشروع")},text={Column(Modifier.heightIn(max=500.dp).verticalScroll(rememberScrollState())) {
        Field(title,{title=it},"العنوان") ;Field(work,{work=it},"عنوان العمل") ;Field(author,{author=it},"المؤلف")
        Field(library,{library=it},"المكتبة") ;Field(shelfmark,{shelfmark=it},"رقم الحفظ") ;Field(desc,{desc=it},"معلومات إضافية")
    }},confirmButton={TextButton(enabled=title.isNotBlank(),onClick={onSave(p.copy(title=title,description=desc,library=library,shelfmark=shelfmark,author=author,work=work))}){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}
@Composable private fun PageDialog(p:Page,onDismiss:()->Unit,onSave:(Page)->Unit){
    var name by remember{mutableStateOf(p.name)};var folio by remember{mutableStateOf(p.folio)};var side by remember{mutableStateOf(p.side)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("بيانات الورقة")},text={Column {Field(name,{name=it},"اسم الصورة");Field(folio,{folio=it},"رقم الورقة");Field(side,{side=it},"وجه / ظهر")}},confirmButton={TextButton(onClick={onSave(p.copy(name=name,folio=folio,side=side))}){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}
@Composable private fun Field(value:String,onValue:(String)->Unit,label:String){OutlinedTextField(value,onValue,label={Text(label)},modifier=Modifier.fillMaxWidth().padding(vertical=3.dp),minLines=1)}
@Composable private fun NoteDialog(existing:Note?,pageId:Long,mark:Mark,onDismiss:()->Unit,onSave:(Note)->Unit,onDelete:(()->Unit)?){
    var title by remember(existing?.id){mutableStateOf(existing?.title?:"")}
    var category by remember(existing?.id){mutableStateOf(existing?.category?:"تقييد")}
    var observation by remember(existing?.id){mutableStateOf(existing?.observation?:"")}
    var reading by remember(existing?.id){mutableStateOf(existing?.reading?:"")}
    var interpretation by remember(existing?.id){mutableStateOf(existing?.interpretation?:"")}
    var confidence by remember(existing?.id){mutableStateOf(existing?.confidence?:"غير محسوم")}
    var references by remember(existing?.id){mutableStateOf(existing?.references?:"")}
    var researcher by remember(existing?.id){mutableStateOf(existing?.researcher?:"")}
    var deleteConfirm by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"تسجيل شاهد بصري" else "تحرير الشاهد رقم ${existing.id}")},text={Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState())) {
        Field(title,{title=it},"عنوان الشاهد")
        Text("التصنيف",fontWeight=FontWeight.SemiBold)
        LazyRow(horizontalArrangement=Arrangement.spacedBy(4.dp)){items(categories){cat->FilterChip(selected=cat==category,onClick={category=cat},label={Text(cat)})}}
        Field(category,{category=it},"تصنيف مخصص (اختياري)")
        Field(observation,{observation=it},"المشاهدة المباشرة — ما يظهر في الصورة")
        Field(reading,{reading=it},"القراءة الدبلوماسية المقترحة")
        Field(interpretation,{interpretation=it},"التفسير والتحليل")
        Text("درجة اليقين",fontWeight=FontWeight.SemiBold)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("مؤكد","محتمل","غير محسوم").forEach{c->FilterChip(selected=confidence==c,onClick={confidence=c},label={Text(c)})}}
        Field(references,{references=it},"المراجع / أدلة الاستدلال")
        Field(researcher,{researcher=it},"اسم الباحث")
        if(existing!=null&&onDelete!=null)TextButton(onClick={deleteConfirm=true}){Text("حذف الشاهد",color=Color.Red)}
    }},confirmButton={TextButton(enabled=title.isNotBlank(),onClick={onSave(Note(id=existing?.id?:0L,pageId=pageId,x=mark.x,y=mark.y,w=mark.w,h=mark.h,category=category,title=title,observation=observation,interpretation=interpretation,confidence=confidence,
        uuid=existing?.uuid?:UUID.randomUUID().toString(),geometry=mark.geometry,vertices=mark.vertices,reading=reading,references=references,researcher=researcher))}){Text("حفظ الشاهد")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
    if(deleteConfirm)AlertDialog(onDismissRequest={deleteConfirm=false},title={Text("تأكيد الحذف")},text={Text("سيُحذف الشاهد وعلاقاته وتاريخه، ولا يمكن استرداده إلا من نسخة احتياطية.")},confirmButton={TextButton(onClick={deleteConfirm=false;onDelete?.invoke()}){Text("حذف نهائي",color=Color.Red)}},dismissButton={TextButton(onClick={deleteConfirm=false}){Text("إلغاء")}})
}
@Composable private fun RelationDialog(note:Note,all:List<Note>,existing:List<Relation>,onDismiss:()->Unit,onAdd:(Long,String,String)->Unit){
    var target by remember{mutableStateOf<Note?>(null)};var expanded by remember{mutableStateOf(false)}
    var type by remember{mutableStateOf("يشابه")};var rationale by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("علاقات الشاهد: ${note.title}")},text={Column {
        val relationText=existing.joinToString{ "${it.sourceNoteId} → ${it.targetNoteId} (${it.type})" }.ifBlank{"لا يوجد"}
        Text("العلاقات القائمة: $relationText")
        Box{OutlinedButton(onClick={expanded=true}){Text(target?.title?:"اختر شاهدًا للربط")}
            DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
                all.filter{it.id!=note.id}.take(300).forEach{n->DropdownMenuItem(text={Text("${n.id} — ${n.title.take(45)}")},onClick={target=n;expanded=false})}
            }
        }
        Field(type,{type=it},"نوع العلاقة")
        Field(rationale,{rationale=it},"مبرر الربط / مصدره")
    }},confirmButton={TextButton(enabled=target!=null,onClick={target?.let{onAdd(it.id,type,rationale)}}){Text("إنشاء علاقة")}},dismissButton={TextButton(onClick=onDismiss){Text("إغلاق")}})
}
