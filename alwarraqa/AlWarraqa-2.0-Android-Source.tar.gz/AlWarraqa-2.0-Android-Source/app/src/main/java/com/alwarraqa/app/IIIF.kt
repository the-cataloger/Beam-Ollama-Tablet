package com.alwarraqa.app

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.security.MessageDigest

object IIIF {
    private fun fetch(url:String):ByteArray {
        require(url.startsWith("https://")){"Requires HTTPS"}
        val conn=(URL(url).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout=14000;readTimeout=20000;instanceFollowRedirects=true
            setRequestProperty("Accept","application/json, application/ld+json, image/*")
        }
        return try {
            require(conn.responseCode in 200..299){"HTTP ${conn.responseCode}"}
            require(conn.url.protocol=="https"){"HTTPS redirect required"}
            val bytes=conn.inputStream.use { ins->val out=java.io.ByteArrayOutputStream();val b=ByteArray(8192);while(true){val n=ins.read(b);if(n<0)break;out.write(b,0,n);require(out.size()<40_000_000){"Remote file too large"}};out.toByteArray() }
            bytes
        } finally {conn.disconnect()}
    }
    data class CanvasEntry(val label:String,val imageUrl:String,val canvasId:String)
    fun parseManifest(raw:String):List<CanvasEntry> {
        val o=JSONObject(raw);val result=mutableListOf<CanvasEntry>()
        val v2=o.optJSONArray("sequences")
        if(v2!=null) for(i in 0 until v2.length()) {
            val canvases=v2.optJSONObject(i)?.optJSONArray("canvases")?:continue
            for(j in 0 until canvases.length()){
                val c=canvases.optJSONObject(j)?:continue
                val resource=c.optJSONArray("images")?.optJSONObject(0)?.optJSONObject("resource")?:continue
                val id=resource.optString("@id").ifBlank{resource.optString("id")}
                val service=resource.optJSONObject("service")?.optString("@id")?:""
                val image=if(service.isNotBlank())"${service.trimEnd('/')}/full/max/0/default.jpg" else id
                if(image.startsWith("https://"))result+=CanvasEntry(c.optString("label","ورقة ${j+1}"),image,c.optString("@id"))
            }
        }
        val v3=o.optJSONArray("items")
        if(v3!=null) for(i in 0 until v3.length()) {
            val c=v3.optJSONObject(i)?:continue
            val body=c.optJSONArray("items")?.optJSONObject(0)?.optJSONArray("items")?.optJSONObject(0)?.optJSONObject("body")?:continue
            val service=body.optJSONArray("service")?.optJSONObject(0)?.optString("id")?:""
            val image=if(service.isNotBlank())"${service.trimEnd('/')}/full/max/0/default.jpg" else body.optString("id")
            if(image.startsWith("https://")) {
                val labelObj=c.optJSONObject("label")
                val vals=labelObj?.optJSONArray("none")?:labelObj?.optJSONArray("en")?:labelObj?.optJSONArray("ar")
                val label=vals?.optString(0)?:"ورقة ${i+1}"
                result+=CanvasEntry(label,image,c.optString("id"))
            }
        }
        require(result.isNotEmpty()){ "No supported IIIF v2/v3 canvases" }
        return result.take(5000)
    }
    fun importManifest(url:String):List<CanvasEntry> = parseManifest(String(fetch(url),Charsets.UTF_8))
    fun cacheImage(context:Context,url:String):File {
        require(url.startsWith("https://"))
        val hash=MessageDigest.getInstance("SHA-256").digest(url.toByteArray()).joinToString(""){"%02x".format(it)}
        val f=File(context.cacheDir,"iiif_${hash}.img")
        if(!f.exists()||f.length()==0L) {
            val b=fetch(url);require(b.size<=40_000_000){"Image too large"};f.writeBytes(b)
        }
        return f
    }
}
