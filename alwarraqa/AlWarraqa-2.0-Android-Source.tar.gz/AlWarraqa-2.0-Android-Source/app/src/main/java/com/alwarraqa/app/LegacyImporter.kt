package com.alwarraqa.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Rehydrates legacy v1 JSON backups as NEW projects without overwriting existing records.
 * This is deliberately separate from direct signed-app SQLite migration.
 * Legacy layouts supported: nested projects/pages/notes or flat arrays with foreign IDs.
 */
object LegacyImporter {
    private fun JSONObject.s(vararg names:String):String = names.firstNotNullOfOrNull { k -> optString(k).takeIf{it.isNotBlank()&&it!="null"} }?:""
    private fun JSONObject.l(vararg names:String):Long = names.firstNotNullOfOrNull { k ->
        if(!has(k))null else optLong(k).takeIf{it!=0L}
    }?:0L
    private fun JSONObject.a(name:String):List<JSONObject> = optJSONArray(name)?.let { a-> (0 until a.length()).mapNotNull{a.optJSONObject(it)} }?:emptyList()
    fun import(context:Context,folder:File,manifest:JSONObject):Pair<Int,Int> {
        val roots=manifest.a("projects")
        require(roots.isNotEmpty()){"No recognizable legacy projects"}
        val oldPages=manifest.a("pages");val oldNotes=manifest.a("notes")
        val db=Store(context);var countProjects=0;var countNotes=0
        try {
            roots.forEach{oldProject->
                val title=oldProject.s("title","name")
                require(title.isNotBlank()){"Project has no title"}
                val pId=db.createProject(title)
                db.updateProject(Project(pId,title,oldProject.s("description"),oldProject.s("library"),oldProject.s("shelfmark"),oldProject.s("author"),oldProject.s("work")))
                countProjects++
                val origId=oldProject.l("id","projectId")
                val pages=oldProject.a("pages").ifEmpty{oldPages.filter{origId!=0L&&it.l("project_id","projectId")==origId}}
                pages.forEachIndexed{idx,oldPage->
                    val origPageId=oldPage.l("id","pageId")
                    val candidates=mutableListOf<String>()
                    for(key in listOf("file","image","path","imagePath")){
                        val value=oldPage.s(key)
                        if(value.startsWith("images/"))candidates+=value
                        else if(value.isNotEmpty())candidates+="images/"+File(value).name
                    }
                    candidates+="images/${idx}.img"
                    if(origPageId!=0L)candidates+="images/$origPageId.img"
                    val source=candidates.map{File(folder,it)}.firstOrNull{it.isFile}
                    // Do not silently fabricate image links: a missing image is reported.
                    require(source!=null){"Image missing for page $origPageId (expected one of $candidates)"}
                    val dest=File(context.filesDir,"images/${UUID.randomUUID()}.img");dest.parentFile?.mkdirs();source.copyTo(dest)
                    val newId=db.addPage(pId,oldPage.s("name","label").ifBlank{"ورقة ${idx+1}"},dest.path,Backup.sha256File(dest))
                    val nested=oldPage.a("notes")
                    val pageNotes=if(nested.isNotEmpty())nested else oldNotes.filter{origPageId!=0L&&it.l("page_id","pageId")==origPageId}
                    pageNotes.forEach{old->
                        db.saveNote(Note(0L,newId,old.optDouble("x",0.0).toFloat(),old.optDouble("y",0.0).toFloat(),old.optDouble("w",0.0).toFloat(),old.optDouble("h",0.0).toFloat(),
                            old.s("category"),old.s("title").ifBlank{"شاهد"},old.s("observation"),old.s("interpretation"),old.s("confidence").ifBlank{"غير محسوم"},
                            uuid=UUID.randomUUID().toString(),reading=old.s("reading"),references=old.s("references"),researcher=old.s("researcher")))
                        countNotes++
                    }
                }
            }
        }finally{db.close()}
        return countProjects to countNotes
    }
}
