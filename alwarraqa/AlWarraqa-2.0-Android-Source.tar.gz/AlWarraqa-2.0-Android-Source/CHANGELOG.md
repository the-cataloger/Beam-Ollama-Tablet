# Changelog
## 2.0.0 (source, October 2026)
- Rebuilt scientific data model on top of legacy `warraqa.db`, with additive migration.
- Documented observation/transcription/interpretation, confidence, provenance and audit revisions.
- Polygon/point/rectangle annotations; normalized coordinates; movable annotations.
- Native tiled raster viewing; side-by-side page comparison; HTTPS IIIF v2/v3 import.
- Structured relation graph; Arabic FTS4; DOCX/XLSX/CSV/JSON and visual PDF exports.
- SHA-256 verified ZIP backup/restore, with legacy JSON backup importer (conditional).
- Source-only CI workflow; Android SDK signing/build and device QA pending.
